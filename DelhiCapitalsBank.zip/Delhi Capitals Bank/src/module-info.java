/**
 * 
 */
/**
 * @author Admin
 *
 */
module OnlineBankingSystem {
	requires java.sql;
}