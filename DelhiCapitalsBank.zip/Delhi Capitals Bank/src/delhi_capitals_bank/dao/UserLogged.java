package delhi_capitals_bank.dao;

public class UserLogged {
   public static int UserLoggedInId;
}
