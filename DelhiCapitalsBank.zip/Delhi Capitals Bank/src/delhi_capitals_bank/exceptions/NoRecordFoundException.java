package delhi_capitals_bank.exceptions;

public class NoRecordFoundException extends Exception {
	 public NoRecordFoundException(String msg) {
		   super(msg);
	   }
}
