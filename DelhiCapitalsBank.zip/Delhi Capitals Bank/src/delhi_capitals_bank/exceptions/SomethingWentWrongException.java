package delhi_capitals_bank.exceptions;

public class SomethingWentWrongException extends Exception {
   public SomethingWentWrongException(String msg) {
	   super(msg);
   }
}
